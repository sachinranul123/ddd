export const environment = {
  production: true,
    isMockEnabled: false,
    fileLocation: '/assets/files',
    apiUrl: 'Http://10.71.80.50:8080/erl-api/',
   
};

