import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent {


  @Input() collapsed = true;
  @Input() screenWidth=0;
  constructor() { }


  getBodyClass():string{
console.log(this.collapsed,"body")
    let styleClass='';
    if (this.collapsed && this.screenWidth>768) {
      styleClass='body-trimed'
    }else if(this.collapsed && this.screenWidth<=768 && this.screenWidth>0){
      styleClass='body-md-screen'
    }
    console.log(styleClass,"body styleClass")
   return styleClass;
  }

}
