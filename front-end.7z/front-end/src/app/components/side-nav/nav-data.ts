export const navbarData=[
    {
        routeLink:'new-policy',
        icon:'fa fa-book',
        label:'New Poilcy'
    }, {
        routeLink:'renew-policy',
        icon:'fa fa-file-text',
        label:'Renew Poilcy'
    }, {
        routeLink:'login',
        icon:'fa fa-sign-in',
        label:'Login'
    },{
        routeLink:'cisil-policy',
        icon:'fa fa-file',
        label:'Cisil'
    },
];