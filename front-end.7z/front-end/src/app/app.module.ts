import { NgModule } from '@angular/core';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'

import { AppRoutingModule,routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatTableModule } from '@angular/material/table';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { BodyComponent } from './components/body/body.component';
import { DashboardComponent } from './components/dashboard/dashboard.component'
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatCardModule} from '@angular/material/card';
import {MatTabsModule} from '@angular/material/tabs';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import {SweetAlert2Module} from '@sweetalert2/ngx-sweetalert2';
import { RenewPolicyDetailsComponent } from './@components/renew-policy-details/renew-policy-details.component';
import { CisilPolicySearchComponent } from './@components/cisil-policy-search/cisil-policy-search.component';

@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    SideNavComponent,
    BodyComponent,
    DashboardComponent,
    RenewPolicyDetailsComponent,
    CisilPolicySearchComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatTableModule,
    MatCardModule,
    MatTabsModule,
    MatSelectModule,
    MatPaginatorModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatButtonModule,
    SweetAlert2Module.forRoot(),
    
  ],
  providers: [ DatePipe,CurrencyPipe,],
  bootstrap: [AppComponent]
})
export class AppModule { }
