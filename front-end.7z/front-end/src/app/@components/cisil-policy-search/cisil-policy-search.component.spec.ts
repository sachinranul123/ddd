import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CisilPolicySearchComponent } from './cisil-policy-search.component';

describe('CisilPolicySearchComponent', () => {
  let component: CisilPolicySearchComponent;
  let fixture: ComponentFixture<CisilPolicySearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CisilPolicySearchComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CisilPolicySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
