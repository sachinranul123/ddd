import { Component, OnInit } from '@angular/core';
import { CisilPolicySearchService } from 'src/app/@core/service/cisil-policy-search.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-cisil-policy-search',
  templateUrl: './cisil-policy-search.component.html',
  styleUrls: ['./cisil-policy-search.component.css']
})
export class CisilPolicySearchComponent implements OnInit {

  policyNumber: any="";
  constructor(
    private cisilPolicySearchService: CisilPolicySearchService ,
  ) { }

  ngOnInit(): void {
  }
  searchPolicy() {
    if (this.policyNumber=="" || this.policyNumber.trim().length==0) {
      Swal.fire({
        imageUrl: 'assets/img/error.png',
        title: 'Error !',
        text: 'policy Number Empty',
        confirmButtonColor: '#4caf50',
        showConfirmButton: true
      });
    }
    this.cisilPolicySearchService.updatePolicy(this.policyNumber)
        .subscribe(response => {
          if (response) {
            Swal.fire({
              imageUrl: 'assets/img/error.png',
              title: 'success !',
              text: 'Data Uploded',
              confirmButtonColor: '#4caf50',
              showConfirmButton: true
            });
          }
        });
        this.policyNumber="";
}

}
