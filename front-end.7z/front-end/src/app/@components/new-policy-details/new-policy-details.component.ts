import { Component, OnInit,ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { SwalComponent ,SwalPortalTargets} from '@sweetalert2/ngx-sweetalert2';
import { ExcelGenerateService } from 'src/app/@core/service/excel-generate.service';
import { NewPolicyDetailsService } from 'src/app/@core/service/new-policy-details.service';
import { PdfGenerateServiceService } from 'src/app/@core/service/pdf-generate-service.service';


export interface newPolicy {
  
  id: number;
  policyNo: number;
  vehicleNo:string;
  policyStatus:string;
  businessType:string;
  policySendStatus: string;
  referenceNo:string;
  dataSendDate: string;
  stageGrpInceptionDate:string;
  

}


@Component({
  selector: 'app-new-policy-details',
  templateUrl: './new-policy-details.component.html',
  styleUrls: ['./new-policy-details.component.css']
})

export class NewPolicyDetailsComponent implements OnInit {

  @ViewChild(MatPaginator) paginator :any = MatPaginator;
  @ViewChild('swalPortal') swalPortal: any = SwalComponent;
  newPolicyRes: newPolicy[] = [];
  pendingNewPolicyRes: newPolicy[] = [];
  sentNewPolicyRes: newPolicy[] = [];
  failedNewPolicyRes: newPolicy[] = [];
  displayedColumns: any[] = ['id', 'policyNo','vehicleNo' , 'policyStatus','businessType', 'policySendStatus', 'referenceNo', 'dataSendDate','stageGrpInceptionDate'];
  tabId: string = "SENT";
  reportData: any=[];
  reportBody: any=[];
  newPolicyMatTable = new MatTableDataSource<newPolicy>();
  constructor(
    private newPolicyDetailsService: NewPolicyDetailsService ,
    public swalTargets: SwalPortalTargets,
    private pdfGenerateService: PdfGenerateServiceService,
    private excelGenerateService: ExcelGenerateService
  ) { 
  
  }

  ngOnInit(): void {
    this.getAll();
  }
  ngAfterViewInit(): void {
    this.newPolicyMatTable.paginator = this.paginator; 
  }
  getAll() {
    this.newPolicyDetailsService.getAll()
        .subscribe(response => {
            if (response) {
             this.newPolicyRes=response as [];
             this.newPolicyRes.forEach(element => {
              if (element.policySendStatus=="PENDING") {
                this.pendingNewPolicyRes.push(element);
              }else if (element.policySendStatus=="SENT") {
                this.sentNewPolicyRes.push(element);
              }else{
                this.failedNewPolicyRes.push(element);
              }
  
              });
             this.newPolicyMatTable.data=this.pendingNewPolicyRes;
             this.reportData = this.pendingNewPolicyRes;
                
            } 
        });
}
onTabChange(event: MatTabChangeEvent): void{       
  this.tabId = event.tab.textLabel;  
  if (this.tabId=="Pending") {
    this.newPolicyMatTable.data=this.pendingNewPolicyRes;
    this.reportData = this.pendingNewPolicyRes;
  }else if (this.tabId=="Sent") {
    this.newPolicyMatTable.data=this.sentNewPolicyRes;
    this.reportData = this.sentNewPolicyRes;
  }else{
    this.newPolicyMatTable.data=this.failedNewPolicyRes;
    this.reportData = this.failedNewPolicyRes;
  }
}
showReportPopup(): void {
  this.swalPortal.fire().then();
}
pushData(row:any,data:any):any{
  if((data.policyNo != null)&&(data.policyNo != undefined)){
    row.push( data.policyNo);
}else{
    data.policyNo = 'NA'
    row.push( data.policyNo);
}
if((data.vehicleNo != null)&&(data.vehicleNo != undefined)){
  row.push( data.vehicleNo);
 }else{
  data.vehicleNo = 'NA'
  row.push( data.vehicleNo);
}
if((data.policyStatus != null)&&(data.policyStatus != undefined)){
    row.push( data.policyStatus);
}else{
    data.policyStatus = 'NA'
    row.push( data.policyStatus);
} 
if((data.businessType != null)&&(data.businessType != undefined)){
  row.push( data.businessType);
}else{
  data.businessType = 'NA'
  row.push( data.businessType);
}
return row;
}
pushData1(row : any,data:any):any{
  if((data.policySendStatus != null)&&(data.policySendStatus != undefined)){
    row.push( data.policySendStatus);
  }else{
    data.policySendStatus = 'NA'
    row.push( data.policySendStatus);
  }
  if((data.referenceNo != null)&&(data.referenceNo != undefined)){
      row.push( data.referenceNo);
  }else{
      data.referenceNo = 'NA'
      row.push( data.referenceNo);               
  }
  
  if((data.dataSendDate != null)&&(data.dataSendDate != undefined)){
      row.push( data.dataSendDate);
  }else{
      data.dataSendDate = 'NA'
      row.push( data.dataSendDate);
  }  
  if((data.stageGrpInceptionDate != null)&&(data.stageGrpInceptionDate != undefined)){
    row.push( data.stageGrpInceptionDate);
}else{
    data.stageGrpInceptionDate = 'NA'
    row.push( data.stageGrpInceptionDate);
}   
return row;
}
  
 generateReportData(): any{    
  
  for (var key in this.reportData) 
  {
      if (this.reportData.hasOwnProperty(key))
      {
          var data = this.reportData[key];
          var row = new Array();            
          
         
        this.reportBody.push(this.pushData1(this.pushData(row,data),data));
      }
    }      
    console.log("this.reportBody "+JSON.stringify(this.reportBody));
   
  return this.reportBody;
 }


  exportToExcel() {
      this.reportBody = [];
      let reportData = {
        title: 'EREVENUE NEW POLICY REPORT',
        data: this.generateReportData(),
        headers: ['Policy No', 'Vehicle No', 'Policy Status', 'Business Type', 'Policy Send Status', 'Reference No','Data Send Date','Inception Date']
      }
      this.excelGenerateService.exportExcel(reportData);
    } 
   
 
  generatePDF() {  
      this.reportBody = [];
      var headers = {
          fila_0:{
              col_1:{ text: 'Policy No', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_2:{ text: 'Vehicle No', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_3:{ text: 'Policy Status', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_4:{ text: 'Business Type', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_5:{ text: 'Policy Send Status', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_6:{ text: 'Reference No', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_7:{ text: 'Data Send Date', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
              col_8:{ text: 'Inception Date', style: 'tableHeader',rowSpan: 2, alignment: 'center',margin: [0, 6, 0, 0] },
          },
          fila_1:{
            col_1:{ text: 'Header 1', style: 'tableHeader', alignment: 'center' },
            col_2:{ text: 'Header 2', style: 'tableHeader', alignment: 'center' }, 
            col_3:{ text: 'Header 3', style: 'tableHeader', alignment: 'center' },
            col_4:{ text: 'Citación', style: 'tableHeader', alignment: 'center' },
            col_5:{ text: 'Cumplimiento', style: 'tableHeader', alignment: 'center'},
            col_6:{ text: 'Header 1', style: 'tableHeader', alignment: 'right' },
            col_7:{ text: 'Header 1', style: 'tableHeader', alignment: 'right' },
            col_8:{ text: 'Header 1', style: 'tableHeader', alignment: 'right' },
          }
      }
    
      for (var key in headers){
          if (headers.hasOwnProperty(key)){
              // var header = headers[key];
              var row = new Array();
              row.push( headers.fila_0.col_1 );
              row.push( headers.fila_0.col_2 );
              row.push( headers.fila_0.col_3 );
              row.push( headers.fila_0.col_4);
              row.push( headers.fila_0.col_5);
              row.push( headers.fila_0.col_6);
              row.push( headers.fila_0.col_7);
              row.push( headers.fila_0.col_8);
              this.reportBody.push(row);
          }
      }
      let reportData = {
       
          title: 'EREVENUE NEW POLICY REPORT\n',
          data: this.generateReportData(),
          tableFontSize: 8,
          fileName: 'EREVENUE NEW POLICY REPORT.pdf',
          // headers: ['auto', 'auto', 'auto', 'auto', 'auto','auto', 'auto', ]
        }

      this.pdfGenerateService.generatePdf(reportData);
       
  } 
  download(type:any){
    if (type=="PDF") {
      this.generatePDF();
    }else if(type=="EXCEL"){
      this.exportToExcel();
    }
  }

  applyPendingFilter(event: Event) {    
    const filterValue = (event.target as HTMLInputElement).value;  
    this.newPolicyMatTable.filter=filterValue.trim().toLocaleLowerCase();
  }
}
