import { TestBed } from '@angular/core/testing';

import { NewPolicyDetailsService } from './new-policy-details.service';

describe('NewPolicyDetailsService', () => {
  let service: NewPolicyDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewPolicyDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
