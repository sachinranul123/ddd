import { TestBed } from '@angular/core/testing';

import { CisilPolicySearchService } from './cisil-policy-search.service';

describe('CisilPolicySearchService', () => {
  let service: CisilPolicySearchService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CisilPolicySearchService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
