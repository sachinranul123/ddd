import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

const mainUrl = `${environment.apiUrl}`;
@Injectable({
  providedIn: 'root'
})
export class RenewPolicyDetailsService {

  constructor(private http: HttpClient) { }
  getAll() {
    return this.http.get<any>(mainUrl+`renew-policy/getAll`);
  }
}
