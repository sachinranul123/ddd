import { CurrencyPipe, DatePipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';


@Injectable({
  providedIn: 'root'
})
export class ExcelGenerateService {
  date: Date=new Date();

 
  constructor(public datepipe: DatePipe,
    private currency:CurrencyPipe
    ) { }
  

  exportExcel(excelData :any) {


    this.date=new Date();
    let latest_date =this.datepipe.transform(this.date, 'yyyy-MM-dd');
 
    const title = excelData.title;
    const header = excelData.headers
    const data = excelData.data;
    const depositTotal= excelData.depositTotal;

console.log(data);
  
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Sales Data');


  
    worksheet.mergeCells('C1', 'F4');
    let titleRow = worksheet.getCell('C1');
    titleRow.value = title
    titleRow.font = {
      name: 'Calibri',
      size: 18,
    
      bold: true,
     color: { argb: '0085A3' }
    }
    titleRow.alignment = { vertical: 'middle', horizontal: 'center' }

    worksheet.addRow([]);
  
    worksheet.mergeCells('G5', 'I7');
    let printDate = worksheet.getCell('G5');
    printDate.value = "Printed Date :" + latest_date;
    printDate.font = {
      name: 'Calibri',
      size: 10,
    
      bold: true,
     color: { argb: '000000' }
    }
    printDate.alignment = { vertical: 'middle', horizontal: 'center' }

    worksheet.addRow([]);

    let headerRow = worksheet.addRow(header);
    headerRow.eachCell((cell:any, number:any) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '4167B8' },
        bgColor: { argb: '' }
      }
      cell.font = {
        bold: true,
        color: { argb: 'FFFFFF' },
        size: 12
      }
    })
    data.forEach((d: any) =>{
       worksheet.addRow(d);
  
    }
 
    );

    worksheet.getColumn(1).width = 20;
    worksheet.getColumn(2).width = 20;
    worksheet.getColumn(3).width = 20;
    worksheet.getColumn(4).width = 20;
    worksheet.getColumn(5).width = 20;
    worksheet.getColumn(6).width = 20;
    worksheet.getColumn(7).width = 20;
    worksheet.getColumn(8).width = 20;
    worksheet.getColumn(9).width = 20;
    worksheet.getColumn(10).width = 20;
    worksheet.getColumn(11).width = 20;
    worksheet.getColumn(12).width = 20;
    worksheet.getColumn(13).width = 20;

    worksheet.addRow([]);
  
    


  
    workbook.xlsx.writeBuffer().then((worksheet: any) => {
      let blob = new Blob([worksheet], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, title + '.xlsx');
    })

  }
}
