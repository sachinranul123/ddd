import { TestBed } from '@angular/core/testing';

import { RenewPolicyDetailsService } from './renew-policy-details.service';

describe('RenewPolicyDetailsService', () => {
  let service: RenewPolicyDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RenewPolicyDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
