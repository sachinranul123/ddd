

import { Injectable } from '@angular/core';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import {  DatePipe } from '@angular/common';

(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;

@Injectable({
  providedIn: 'root'
})
export class PdfGenerateServiceService {
  date: Date=new Date();

  constructor(private datepipe: DatePipe,) {  
        (window as any).pdfMake.vfs = pdfFonts.pdfMake.vfs;
    }

  generatePdf(reportData: any){

    
    this.date=new Date();
    let latest_date =this.datepipe.transform(this.date, 'yyyy-MM-dd');
    

    let docDefinition = {   
                                
                content: [  
                            {  
                                text:  '           Allianz Insurance Lanka Limited\n'+
                                'No 675, Dr.Danister De Silva Mawatha, Colombo 09\n'+
                            ' Tel: 0112303300\n'+
                                'Fax: 0112334864 / 0117309299',
                                        
                                fontSize: 8,  
                                alignment: 'left',  
                                bold: true,  
                            
                            },  
                            {  
                                text: '\n',       
                
                            },  
                    
                            {  
                            text: reportData.title,  
                            fontSize: 16,  
                            alignment: 'center',  
                            color: '#000080	'  ,
                            bold: true,  
                            fillColor: '#dedede'
                            },  
                            {  
                                text: '\n',       
                
                            },  
                            {  
                                text: "Printed Date :" + latest_date,  
                                fontSize: 8,  
                                alignment: 'right',  
                                color: '#000000	'  ,
                                bold: true,  
                                fillColor: '#000000	' 
                                },  
                            {  
                                text: '\n',       
                
                            },  
                    
                            {    fontSize: reportData.tableFontSize,  
                                alignment: 'right',  
                                table: {
                                    widths: reportData.header,
                                    
                                    fontSize: 4,  
                                    body: reportData.data
                                }
                            },
                            {  
                              text: '\n',       
              
                          },
                          
                            
                                ]  ,
                                styles: {  
                                    sectionHeader: {  
                                        bold: true,  
                                        decoration: 'underline',  
                                        fontSize: 8,  
                                        margin: [0, 15, 0, 15]  
                                    }  
                                }   ,
                                images: {
                                    mySuperImage: 'data:image/jpeg;base64,...content...',
                                    snow: 'src/assets/img/allianz-logo-2.png'
                                }
                                };  
                                console.log(docDefinition);
                       let pdfMaker = require('pdfMake');
                      pdfMaker.createPdf(docDefinition).download(reportData.fileName);

  
                    
  } 

 

}


