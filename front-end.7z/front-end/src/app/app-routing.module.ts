import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CisilPolicySearchComponent } from './@components/cisil-policy-search/cisil-policy-search.component';
import { LoginComponent } from './@components/login/login.component';
import { NewPolicyDetailsComponent } from './@components/new-policy-details/new-policy-details.component';
import { RenewPolicyDetailsComponent } from './@components/renew-policy-details/renew-policy-details.component';

const routes: Routes = [
  { path: 'new-policy', component: NewPolicyDetailsComponent },
  { path: 'renew-policy', component: RenewPolicyDetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'cisil-policy', component: CisilPolicySearchComponent },
  { path: '**', component: LoginComponent },  
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true,
    relativeLinkResolution: 'legacy'
})],
  exports: [RouterModule]
})
export class AppRoutingModule {

  
 }
 export const routingComponents =[NewPolicyDetailsComponent,LoginComponent]
