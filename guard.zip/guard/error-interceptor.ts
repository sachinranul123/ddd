import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { LogoutService } from '../service/logout.service';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private logoutService: LogoutService, private router:Router) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      return next.handle(request).pipe(catchError(err => {
          if (err.status === 401) {
         
          Swal.fire({
               imageUrl: 'assets/img/error.png',
                title: 'Warning !',
                text: 'Session is Expired please Log in',
                confirmButtonColor: '#4cc173',
                showConfirmButton: true
        }).then(() => {
            this.router.navigate(['logout']).then(() => {
                window.location.reload();
            });
        });
          }
          
          const error = err.error.message || err.statusText;
          return throwError(error);
      }))
  }
}