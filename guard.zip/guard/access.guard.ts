import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree} from '@angular/router';

import {Observable} from 'rxjs';

import {environment} from '../../../environments/environment';
import {ModalAlertComponent} from '../../shared/components/modal-alert/modal-alert.component';
import {
    RULE_DBR_MAP_CONFIGURATION,
    RULE_DBR_BRANCH_UPLOAD,
    RULE_DBR_CANCELLATIONS,
    RULE_DBR_AUTHORIZATION,
    RULE_DBR_BRANCH_HISTORY,
    RULE_DBR_RECEIPT_DETAILS,
    RULE_DBR_UPLOAD_TRACKING,
    RULE_DBR_BRANCH_REPORTS,
    SESSION_KEY_LOGGED_USER,
    RULE_DBR_FINANCE_REPORTS,

} from '../../shared/constants';
import { AuthServiceService } from '../service/auth-service.service';
import {SecureSessionStorageService} from '../service/secure-session-storage.service';

@Injectable({
    providedIn: 'root'
})
export class AccessGuard implements CanActivateChild {

    private authorizedUrl: string = null;
    

    constructor(
        private secureStorage: SecureSessionStorageService,
       
        private modalAlert: ModalAlertComponent) {
    }

    canActivateChild(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

        
        if (!this.authorizeUser()) {
            location.href = `${ environment.systemModules.systemSelector }`;
            return false;
        }
        

        return this.hasAccessToSubModule(state.url);
    }

    authorizeUser(): boolean {
        const userObject: any = this.secureStorage.getSecureStorage(SESSION_KEY_LOGGED_USER);

        try {
            return userObject.success;
        } catch {
            return false;
        }
    }
    
    hasAccessToSubModule(url: string): boolean {
        let isAuthorized = false;

        switch (url.toLowerCase()) {
            case '/branch-map':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_MAP_CONFIGURATION);
                break;
            case '/user-map':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_MAP_CONFIGURATION);
                break;            
            case '/dbr-summary':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_BRANCH_HISTORY);
                break;
            case '/cancellation':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_CANCELLATIONS);
                break;
            case '/cancellation-summary':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_CANCELLATIONS);
                break;
            case '/recheck-cancellation':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_CANCELLATIONS);
                break;
            case '/cancellation-authorization':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_AUTHORIZATION);
                break;
            case '/upload-track-report':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_UPLOAD_TRACKING);
                break;
            case '/receipt-detail-report':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_BRANCH_REPORTS);
                break;
            case '/dbr-creation':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_BRANCH_UPLOAD);
                break;
            case '/delay-receipt-report':
                isAuthorized = this.authorizeToSubModule(RULE_DBR_FINANCE_REPORTS);
                break;
            case '/dbr-welcome':
                isAuthorized = true;
                break;

        }
        if (!isAuthorized) {
            if (!this.authorizedUrl) {
                this.authorizedUrl = '/';
            }
        } else {
            this.authorizedUrl = url;
        }
        return isAuthorized;
    }

    authorizeToSubModule(moduleAccessCode: string): boolean {
        const userObject: any = this.secureStorage.getSecureStorage(SESSION_KEY_LOGGED_USER);
        return Array.of(userObject.object.userSystemPrivilege).some((p: string) => p.indexOf(moduleAccessCode) !== -1);
    }

    showNotAuthorized(redirectUrl?: string): void {
        this.modalAlert.show('Sorry!', 'You have no access to this section! Please contact admin for more details...', redirectUrl);
    }
    getFristPage(moduleAccessCode: string): string {
        let path = "";
        switch (moduleAccessCode) {
            case RULE_DBR_MAP_CONFIGURATION:
                path = '/branch-map';
                break;
            case RULE_DBR_BRANCH_UPLOAD:
                path = '/dbr-creation';
                break;
            case RULE_DBR_BRANCH_HISTORY:
                path = '/dbr-summary';
                break;
            case RULE_DBR_CANCELLATIONS:
                path = '/cancellation';
                break;
            case RULE_DBR_AUTHORIZATION:
                path = '/cancellation-authorization';
                break;
            case RULE_DBR_UPLOAD_TRACKING:
                path = '/upload-track-report';
                break;
            case RULE_DBR_RECEIPT_DETAILS:
                path = '/receipt-detail-report';
                break;
            case RULE_DBR_BRANCH_REPORTS:
                path = '/delay-receipt-report';
                break;
            case RULE_DBR_BRANCH_REPORTS:
                    path = '/receipt-detail-report';
                    break;


        }
        return path;

    }
    

}
