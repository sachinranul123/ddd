import { Injectable, OnInit } from '@angular/core';

import { HttpClient } from '@angular/common/http';



@Injectable({
    providedIn: 'root'
  })
export class IpAddress implements OnInit {

    ipAddress = '';
    constructor(private http: HttpClient) { }

    ngOnInit() {
        this.getIPAddress();
    }
    getIPAddress() {

        this.http.get("http://api.ipify.org/?format=json").subscribe((res: any) => {

            this.ipAddress = res.ip;

        });
        console.log(this.ipAddress+"kldlfsfnsdlnmfs");
        return this.ipAddress;

    }


}