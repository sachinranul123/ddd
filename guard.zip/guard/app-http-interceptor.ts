import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import { AuthServiceService } from "../service/auth-service.service";
import { of, throwError } from "rxjs";
import {  tap } from "rxjs/operators";
import { Router } from "@angular/router";
import { SecureSessionStorageService } from "../service/secure-session-storage.service";
import { SESSION_KEY_LOGGED_USER } from "app/shared/constants";
import { IpAddress } from "./ip-address";


@Injectable({
  providedIn: 'root'
})
export class AppHttpInterceptor implements HttpInterceptor {

  constructor(private authenticationService: AuthServiceService,private ipAddress: IpAddress, private secureStorage: SecureSessionStorageService, private router: Router, private http: HttpClient) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log("hit");
    let currentUser = this.authenticationService.currentUserValue;
    console.log(currentUser);
    if (currentUser && currentUser.jwtToken) {
      

      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${currentUser.jwtToken}`,
          'user-audit': this.secureStorage.getSecureStorage(SESSION_KEY_LOGGED_USER)['object']['userName'],
        }
      });
    }
    return next.handle(request).pipe(tap(() => {
      console.log("request");
     },
      (err: any) => {
        console.log(err);
        if (err instanceof HttpErrorResponse) {

          if (err.status !== 401) {
            return;
          }
          this.router.navigate(['/acsfi-login']);
        }
      }));

  }

  private handleAuthError(err: HttpErrorResponse): Observable<any> {

    
    if (err.status === 401 || err.status === 403) {

      window.alert("Connection is time out");


      this.router.navigate(['/acsfi-login'])

      return of(err.message);
    }

    return throwError(err);
  }

}





