package com.example.demo.dto;

public class TestDto {

    private Long id;
    private String area;
    private String name;
    private String unique_id;
    private String party_key;
    private String party_type;
    private String gender;
    private String citizenship;
    private String country_birth;
    private String orresidence;
    private String birthday;
    private String year;
    private String id_value;
    private String id_type;
    private String business_area;
    
    
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getUniqueId() {
        return unique_id;
    }

    public void setUniqueId(String unique_id) {
        this.unique_id = unique_id;
    }
    
    public String getPartyKey() {
        return party_key;
    }

    public void setPartyKey(String party_key) {
        this.party_key = party_key;
    }

    public String getPartyType() {
        return party_type;
    }

    public void setPartyType(String party_type) {
        this.party_type = party_type;
    }
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCitizenship() {
        return citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.citizenship = citizenship;
    }
    public String getCountryBirth() {
        return country_birth;
    }

    public void setCountryBirth(String country_birth) {
        this.country_birth = country_birth;
    }

    public String getOrresidence() {
        return orresidence;
    }

    public void setOrresidence(String orresidence) {
        this.orresidence = orresidence;
    }
    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getIdValue() {
        return id_value;
    }

    public void setIdValue(String id_value) {
        this.id_value = id_value;
    }
    public String getIdType() {
        return id_type;
    }

    public void setIdType(String id_type) {
        this.id_type = id_type;
    }

    public String getBusinessArea() {
        return business_area;
    }

    public void setBusinessArea(String business_area) {
        this.business_area = business_area;
    }
}
