/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.demo.validation;

import org.apache.poi.ss.usermodel.Cell;
import org.springframework.stereotype.Component;

/**
 *
 * @author sachin
 */
@Component
public class ValidationCheck {
    
    public boolean validated=true;
   
    public boolean LengthVAlidation(int length){
        
        if (length<=5) {
           return true;
        }
        validated=false;
        
        return false;
    }
    public boolean EmptyVAlidation(String value){
        
        if (value.isEmpty()) {
           validated=false;
           return false;
        }
        
        return true;
    }
    public boolean TypeVAlidationString(Cell cell){
        
        if (Cell.CELL_TYPE_NUMERIC!=cell.getCellType()) {
           validated=false;
           return false;
        }
        
        return true;
    }
    public boolean TypeVAlidationNurmeric(Cell cell){
        
        if (Cell.CELL_TYPE_NUMERIC!=cell.getCellType()) {
            validated=false;
            return false;
        }
        
        return true;
    }
    
    public boolean DomainTypeVAlidation(String value){
        
        if ("LK".equals(value)||"".equals(value)) {
            return true;
        }
        validated=false;
        return false;
    }
    
    public boolean PartyTypeVAlidation(String value){
        
        if("O".equals(value) || "I".equals(value)||"U".equals(value) ){
            return true;
        }
        validated=false;
        return false;
    }
    public boolean GenderTypeVAlidation(String value){
        
        if("M".equals(value) || "FM".equals(value)||"".equals(value) ){
            return true;
        }
        validated=false;
        return false;
    }
    public boolean HeaderVAlidation(String value){
        
         if( "Area".equals(value)||
                "Name".equals(value)||
                "Party Type".equals(value)||
                "Unique Id".equals(value)||
                "Party Key".equals(value)||
                "Gender".equals(value)||
                "Citizenship".equals(value)||
                "Country Of Birth".equals(value)||
                "Orresidence".equals(value)||
                "Date Of birth".equals(value)||
                "Year".equals(value)||
                "Id Type".equals(value)||
                "Id alue".equals(value)||
                "Business Area".equals(value)){ 
              return true;
            }
        validated=false;
        return false;
    }
    public boolean HeaderLengthVAlidation(int length){
        
        if (length==14) {
           return true;
        }
        validated=false;
        return false;
    }
    public boolean RowCellCountVAlidation(int length){
        
        if (length==14) {
           return true;
        }
        validated=false;
        return false;
    }
    
    
}
