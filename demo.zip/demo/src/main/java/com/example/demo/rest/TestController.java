package com.example.demo.rest;

import com.example.demo.dto.TestDto;
import com.example.demo.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/test")
public class TestController {

    @Autowired
    TestService testService;

    @PostMapping
    public String save(@RequestBody TestDto testDto){
        return testService.Create(testDto);
    }


}
