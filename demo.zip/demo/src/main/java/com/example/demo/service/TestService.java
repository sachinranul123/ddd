package com.example.demo.service;

import com.example.demo.dto.TestDto;
import org.springframework.stereotype.Service;


public interface TestService {

    public String Create(TestDto testDto);

}
