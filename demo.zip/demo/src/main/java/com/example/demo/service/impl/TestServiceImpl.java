package com.example.demo.service.impl;

import com.example.demo.dto.TestDto;
import com.example.demo.entity.TestEntity;
import com.example.demo.repository.TestRepository;
import com.example.demo.service.TestService;
import com.example.demo.validation.ValidationCheck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Header;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ClassPathResource;

@Service
public class TestServiceImpl implements TestService {

    @Autowired
    TestRepository testRepository;
    @Autowired
    ValidationCheck validation;
    
    

    @Override
    public String Create(TestDto testDto) {
        String Area;
        boolean isValidated=true;
        List<TestDto> testArr = new ArrayList<>();
        
        DataFormatter formatter = new DataFormatter();
        
        FileInputStream inputStream;
        
    //  csvv
        FileWriter out;
        try {
            out = new FileWriter("book_new.csv");
        } catch (IOException ex) {
            Logger.getLogger(TestServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }

    // csv
    
    //excel create
    
        XSSFWorkbook workbook1 = new XSSFWorkbook();
        XSSFSheet sheet = workbook1.createSheet("Java Books");

        Row row1=sheet.createRow(0);
        String[] header1 = {"Areas","Name","Party Key","Unique Id","Party Key","Gender","Citizenship","Country Of Birth","Orresidence","Date Of birth","Year","Id Value","Id Type","Business Area"};


        for (int i = 0; i < header1.length; i++) {
            row1.createCell(i).setCellValue(header1[i]);
        }

    //end

        
        try {
            Resource resource = new ClassPathResource("excel.xlsx");
            InputStream input = resource.getInputStream();
            File file = resource.getFile();
            inputStream = new FileInputStream(file);
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet firstSheet = workbook.getSheetAt(0);
//            Row rows = firstSheet.getRow(0);
            Iterator<Row> iterator = firstSheet.iterator();
            System.out.println("rowww count"+iterator.hasNext() ); 
            
            
        //  Header Validation
        //  header cell contains

            Row headerRow= iterator.next();

        for (int i = 0; i < headerRow.getPhysicalNumberOfCells(); i++) { 
        //  Header cell contains validation 
            System.out.println("heder validation" +validation.HeaderVAlidation(headerRow.getCell(i).getStringCellValue()) ); 
     
        }
        //  Header length validation
            String[] header = {"Areas","Name","Party Key","Unique Id","Party Key","Gender","Citizenship","Country Of Birth","Orresidence","Date Of birth","Year","Id Value","Id Type","Business Area"};
   
            System.out.println("length"+validation.HeaderLengthVAlidation(headerRow.getPhysicalNumberOfCells()));
            
        //  End heder validation    
        
        //  ROW data validate
        while (iterator.hasNext()) {
            int s=0;
            TestDto excelDto=new TestDto();
            Row nextRow = iterator.next();
            
            System.out.println("rowwwwwwww"+nextRow.getCell(2).getStringCellValue());
            
                 excelDto.setArea(nextRow.getCell(0).getStringCellValue());
                 excelDto.setName(nextRow.getCell(1).getStringCellValue());
                 excelDto.setPartyType(nextRow.getCell(2).getStringCellValue());
                 excelDto.setUniqueId(nextRow.getCell(3).getStringCellValue());
                 excelDto.setPartyKey(nextRow.getCell(4).getStringCellValue());
                 excelDto.setGender(nextRow.getCell(5).getStringCellValue());
                 excelDto.setCitizenship(nextRow.getCell(6).getStringCellValue());
                 excelDto.setCountryBirth(nextRow.getCell(7).getStringCellValue());
                 excelDto.setOrresidence(nextRow.getCell(8).getStringCellValue());
                 excelDto.setBirthday(nextRow.getCell(9).getStringCellValue());
                 excelDto.setYear(nextRow.getCell(10).getStringCellValue());
                 excelDto.setIdValue(nextRow.getCell(11).getStringCellValue());
                 excelDto.setIdType(nextRow.getCell(12).getStringCellValue());
                 excelDto.setBusinessArea(nextRow.getCell(13).getStringCellValue());
                System.out.println("get dto data"+excelDto.getPartyType());
                 
                 testArr.add(excelDto);
                 
                 
            

            
            if (nextRow==null) {
                System.out.println("rowww cnt"+nextRow ); 
            }
            Iterator<Cell> cellIterator = nextRow.cellIterator();
            System.out.println("cell count"+validation.RowCellCountVAlidation(nextRow.getPhysicalNumberOfCells()));
             if (14!=nextRow.getPhysicalNumberOfCells()){
                isValidated=false;
//                System.out.println("XL document Row Cell Count should be  "+14 +" Uploded XL Row"+nextRow.getRowNum()+" Cell Count is"+nextRow.getPhysicalNumberOfCells());
            } 
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                if("Area".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){    
                    if(validation.LengthVAlidation(cell.getStringCellValue().length())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.EmptyVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                  
                }
                if("Name".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    
                    if(validation.LengthVAlidation(cell.getStringCellValue().length())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.EmptyVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                if("Party Type".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.EmptyVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Empty field");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Empty field");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.PartyTypeVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Unknown Party Type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Unknown Party Type");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }

                }
                if("Unique Id".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.EmptyVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                
                if("Gender".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.EmptyVAlidation(cell.getStringCellValue())==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("error with max length ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if("M".equals(cell.getStringCellValue()) || "FM".equals(cell.getStringCellValue())||"".equals(cell.getStringCellValue()) ){
//                    System.out.println(" type correct "); 
                    }else{
//                    System.out.println(" type  Error");
                    isValidated=false;
                    }
                }
                if("Citizenship".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                   if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if("LKw".equals(cell.getStringCellValue()) ||"ww".equals(cell.getStringCellValue()) ){
//                    System.out.println(" type correct ");
                    }else{
//                    System.out.println(" type  Error");
                    isValidated=false;
                    }
                }
                if("Country Of Birth".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if("LK".equals(cell.getStringCellValue()) ||"".equals(cell.getStringCellValue()) ){
//                    System.out.println(" type correct ");                 
                    }else{
//                    System.out.println(" type  Error");
                    isValidated=false;
                    }
                }
                if("Orresidence".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                if("Country Of Birth".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                    if("LK".equals(cell.getStringCellValue()) ||"".equals(cell.getStringCellValue()) ){
//                    System.out.println(" type correct ");  
                    }else{
//                    System.out.println(" type  Error");
                    isValidated=false;
                    }
                }
                if("Date Of birth".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                if("Year".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(cell.getCellType()!=Cell.CELL_TYPE_STRING){
//                    System.out.println(" wrong type ");
                    isValidated=false;      
                    }
                }
                if("Id Value".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                if("Id Type".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){   
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
                if("Business Area".equals(formatter.formatCellValue(headerRow.getCell(cell.getColumnIndex())))){
                    if(validation.TypeVAlidationString(cell)==false){  
                        if (sheet.getRow(nextRow.getRowNum())==null) {
                            sheet.createRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type");
                        }else{
                        sheet.getRow(nextRow.getRowNum()).createCell(cell.getColumnIndex()).setCellValue("Wrong cell type ");
                        System.out.print(headerRow.getRowNum());
                        cell.getRow();
                        }
                    }
                }
            }
        }

       
       
 
        workbook.close();
        inputStream.close();
        
        }  catch (FileNotFoundException ex) {
            Logger.getLogger(TestServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
            return "erro 3 " +ex;
        } catch (IOException ex) {
            Logger.getLogger(TestServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
             return "erro"+ex;
        }
         try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
            workbook1.write(outputStream);
        } catch (IOException ex) {
            Logger.getLogger(TestServiceImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
         
         System.out.println("array length"+testArr.size());

        if (validation.validated==true) {
            for (TestDto dto : testArr) {
                System.out.println("for ecahi"+dto.getPartyType());
               TestEntity save = testRepository.save(buildEntity(new TestEntity(),dto));   
            }

        }else{
        
        System.out.println("not validated the uploded excel");
        }
        
//        database save 
            
        return "Faild";
    }

    private TestEntity buildEntity(TestEntity testEntity, TestDto testDto) {

        if (testDto == null){
            return null;
        }
            testEntity.setName(testDto.getName());
            testEntity.setArea(testDto.getArea());
            testEntity.setBirthday(testDto.getBirthday());
            testEntity.setCountryBirth(testDto.getCountryBirth());
            testEntity.setBusinessArea(testDto.getBusinessArea());
            testEntity.setGender(testDto.getGender());
            testEntity.setIdType(testDto.getIdType());
            testEntity.setIdValue(testDto.getIdValue());
            testEntity.setOrresidence(testDto.getOrresidence());
            testEntity.setPartyKey(testDto.getPartyKey());
            testEntity.setPartyType(testDto.getPartyType());
            testEntity.setYear(testDto.getYear());
            testEntity.setUniqueId(testDto.getUniqueId());
            testEntity.setCitizenship(testDto.getCitizenship());
            return testEntity;
        
    }


}
